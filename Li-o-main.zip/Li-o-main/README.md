# formularioTesteBackend

OBS: Este formulário foi criado pelo professor Lucas Stasiak junto com o aluno Guilherme do 2ºB Técnico do colégio Lindaura. 
Estou usando para fazer o backend juntamente com os alunos do 3º A técnico do mesmo colégio. 
Ano: 2024 - utilizando para a mostra dos cursos técnicos do colégio.  
#####
###